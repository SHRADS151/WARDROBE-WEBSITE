# Wardrobe Website (Free, GitHub Pages)

This folder contains a ready-to-publish static site for a wardrobe catalog with:
- Catalog grid with images & details
- Add to cart
- Cart page with remove item
- Special instruction box
- WhatsApp share on checkout (opens WhatsApp with pre-filled text)

## How to use

1) Create a **public** GitHub repository (e.g., `wardrobe-website`).
2) Upload **everything** in this `wardrobe-site` folder to your repo, keeping the same structure.
3) Enable GitHub Pages: **Settings → Pages → Build and deployment → Source: Deploy from a branch → Branch: main (root)**.
4) Put your clothing data in `data/clothes.csv`. You can edit it in GitHub or upload a new file.
   - Required columns: `id,title,brand,category,set_details,size,color,purchase_date,image,notes`
   - For `image`, use direct Google Drive links like: `https://drive.google.com/uc?export=view&id=FILE_ID`
     (FILE_ID is the long string from your Drive share link between `/d/` and `/view`)
5) Visit your Pages URL: `https://YOUR_USERNAME.github.io/REPO_NAME`

## Tips
- You can export your Excel to CSV and upload as `data/clothes.csv`.
- If your existing links look like `https://drive.google.com/file/d/FILE_ID/view?...`, they will still work – the site will auto-convert them to direct-view links.
- To send to a specific phone on WhatsApp, type the number on the cart page. If left empty, the generic WhatsApp share picker opens and you can select your wardrobe team group manually.